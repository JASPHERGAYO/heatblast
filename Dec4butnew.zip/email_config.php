<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . "/vendor/autoload.php";

function sendOTPEmail($email, $otp_code) {
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->SMTPDebug = 0; // Set to 0 for production
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'qrviolationrecorder@gmail.com';
        $mail->Password = 'bwrf ymcl ucas zqla'; // Your App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        $mail->Timeout = 30;

        // Recipients - FIXED: Use the same email as your Username
        $mail->setFrom('qrviolationrecorder@gmail.com', 'QR Violation Recorder Portal'); // ← CHANGE THIS LINE
        $mail->addAddress($email);
        $mail->addReplyTo('noreply@kld.edu.ph', 'QR VIOLATION RECORDER No Reply');

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'QR VIOLATION RECORDER - Email Verification Code';
        $mail->Body = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
                .container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
                .header { background: #007bff; color: white; padding: 20px; text-align: center; border-radius: 5px; }
                .otp-code { font-size: 32px; font-weight: bold; text-align: center; margin: 30px 0; color: #007bff; letter-spacing: 5px; }
                .footer { margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; }
                .note { background: #fff3cd; padding: 10px; border-radius: 5px; margin: 15px 0; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>QR Violation Recorder Email Verification</h1>
                </div>
                <p>Hello,</p>
                <p>Thank you for registering with QR Violation Recorder. Use the verification code below to complete your registration:</p>
                
                <div class='otp-code'>$otp_code</div>
                
                <div class='note'>
                    <strong>Note:</strong> This code will expire in 10 minutes.
                </div>
                
                <p>If you didn't request this code, please ignore this email.</p>
                
                <div class='footer'>
                    <p><strong>QR Violation Recorder</strong><br>
                    This is an automated message, please do not reply.</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        $mail->AltBody = " $otp_code\nThis code expires in 10 minutes.";

        return $mail->send();
        
    } catch (Exception $e) {
        error_log("PHPMailer Error: " . $mail->ErrorInfo);
        return false;
    }
}

function sendPasswordResetEmail($email, $code) {
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->SMTPDebug = 0; // Set to 0 for production
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'qrviolationrecorder@gmail.com';
        $mail->Password = 'bwrf ymcl ucas zqla'; // Your App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        $mail->Timeout = 30;

        // Recipients
        $mail->setFrom('qrviolationrecorder@gmail.com', 'QR VIOLATION RECORDER Portal');
        $mail->addAddress($email);
        $mail->addReplyTo('noreply@kld.edu.ph', 'QR Violation Recorder No Reply');

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'QR Violation Recorder - Password Reset Code';
        $mail->Body = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
                .container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
                .header { background: #007bff; color: white; padding: 20px; text-align: center; border-radius: 5px; }
                .otp-code { font-size: 32px; font-weight: bold; text-align: center; margin: 30px 0; color: #007bff; letter-spacing: 5px; }
                .footer { margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; }
                .note { background: #fff3cd; padding: 10px; border-radius: 5px; margin: 15px 0; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>QR Violation Recorder Password Reset</h1>
                </div>
                <p>Hello,</p>
                <p>You have requested to reset your password for your Qr Violation Recorder account. Use the verification code below to proceed:</p>
                
                <div class='otp-code'>$code</div>
                
                <div class='note'>
                    <strong>Note:</strong> This code will expire in 10 minutes.
                </div>
                
                <p>If you didn't request this code, please ignore this email.</p>
                
                <div class='footer'>
                    <p><strong>QR Violation Recorder</strong><br>
                    This is an automated message, please do not reply.</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        $mail->AltBody = "QR Violation Recorder Password Reset Code: $code\nThis code expires in 10 minutes.";

        return $mail->send();
        
    } catch (Exception $e) {
        error_log("PHPMailer Error: " . $mail->ErrorInfo);
        return false;
    }
}
?>