<?php
session_start();
include 'database.php';

// Check if user is logged in as student ONLY
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Prevent admin/staff from accessing this page
if (isset($_SESSION['admin_logged_in']) || isset($_SESSION['staff_logged_in'])) {
    header("Location: profile.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$success_message = '';
$error_message = '';

// Load current user data from users table
$q = $conn->prepare("SELECT full_name, email FROM users WHERE id = ?");
$q->bind_param("i", $user_id);
$q->execute();
$user = $q->get_result()->fetch_assoc();

if (!$user) {
    die("User not found.");
}

// Handle password change only
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Verify current password - check against users table
    $check_q = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $check_q->bind_param("i", $user_id);
    $check_q->execute();
    $result = $check_q->get_result()->fetch_assoc();
    
    if ($result && password_verify($current_password, $result['password'])) {
        if ($new_password === $confirm_password) {
            if (strlen($new_password) >= 8) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $pass_q = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                $pass_q->bind_param("si", $hashed_password, $user_id);
                
                if ($pass_q->execute()) {
                    $success_message = "Password changed successfully!";
                } else {
                    $error_message = "Error changing password: " . $conn->error;
                }
            } else {
                $error_message = "Password must be at least 8 characters long.";
            }
        } else {
            $error_message = "New passwords do not match.";
        }
    } else {
        $error_message = "Current password is incorrect.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Change Password - Student</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .password-container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .info-box {
            background: #e8f4fd;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #2196F3;
        }
        
        .form-section {
            margin-bottom: 30px;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }
        
        .btn-primary {
            background: #2e7d32;
            color: white;
        }
        
        .btn-primary:hover {
            background: #1b5e20;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #545b62;
        }
        
        .message {
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .profile-info {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .profile-info p {
            margin: 5px 0;
        }
        
        .password-requirements {
            background: #fff3cd;
            padding: 10px;
            border-radius: 5px;
            margin: 10px 0;
            font-size: 0.9em;
        }
    </style>
</head>
<body>

<?php include 'nav.php'; ?>

<div class="password-container">
    <h1><i class="fas fa-key"></i> Change Password</h1>
    
    <!-- Information Box -->
    <div class="info-box">
        <h3><i class="fas fa-info-circle"></i> Student Account</h3>
        <p>You can change your password here. For security reasons, personal information cannot be modified by students.</p>
    </div>
    
    <?php if ($success_message): ?>
        <div class="message success"><?= $success_message ?></div>
    <?php endif; ?>
    
    <?php if ($error_message): ?>
        <div class="message error"><?= $error_message ?></div>
    <?php endif; ?>
    
    <!-- Display User Information -->
    <div class="profile-info">
        <h3><i class="fas fa-user"></i> Student Information</h3>
        <p><strong>Name:</strong> <?= htmlspecialchars($user['full_name']) ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
    </div>
    
    <!-- Password Change Form -->
    <div class="form-section">
        <h2><i class="fas fa-lock"></i> Change Your Password</h2>
        
        <div class="password-requirements">
            <strong>Password Requirements:</strong>
            <ul style="margin: 5px 0; padding-left: 20px;">
                <li>At least 8 characters long</li>
                <li>Make it strong with letters, numbers, and symbols</li>
            </ul>
        </div>
        
        <form method="POST">
            <div class="form-group">
                <label>Current Password</label>
                <input type="password" name="current_password" required placeholder="Enter your current password">
            </div>
            
            <div class="form-group">
                <label>New Password</label>
                <input type="password" name="new_password" required minlength="8" placeholder="Enter new password (min. 8 characters)">
            </div>
            
            <div class="form-group">
                <label>Confirm New Password</label>
                <input type="password" name="confirm_password" required minlength="8" placeholder="Confirm your new password">
            </div>
            
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-key"></i> Change Password
            </button>
        </form>
    </div>
    
    <a href="profile.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Back to Profile
    </a>
</div>

<?php include 'footer.php'; ?>
</body>
</html>